<?php 

$conn = mysqli_connect("localhost","root","","users") or die("Connection Failed");

 ?>