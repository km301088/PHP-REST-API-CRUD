<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers,Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With');


$data = json_decode(file_get_contents("php://input"), true);
  require 'connection.php';
  $number=$data['number'];
  $name=$data['name'];
  $username=$data['username'];
  $password=md5($data['password']);



  $checkUser="SELECT * from users WHERE username='$username'";
  $checkQuery=mysqli_query($conn,$checkUser);

  if(mysqli_num_rows($checkQuery)>0){

    $response['error']="403";
  	$response['message']="User exist";
  }
  else
  {
     $insertQuery="INSERT INTO `users`(`number`, `name`, `username`, `password`, `dt`) VALUES('$number','$name','$username','$password',  current_timestamp())";
     if(mysqli_query($conn, $insertQuery)){
      $response['error']="200";
  	  $response['message']="Register successful";
    
    }else{
    
      $response['error']="400";
      $response['message']="Registeration failed!";
    
    }



  }

?>