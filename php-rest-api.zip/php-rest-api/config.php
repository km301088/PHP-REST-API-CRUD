<?php 

$conn = mysqli_connect("localhost","root","","machine_test") or die("Connection Failed");

 ?>